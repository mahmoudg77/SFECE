  <?php echo e(Form::model($post, ['route' => ['Post.update', $post],"method"=>"PUT"])); ?>

  <?php echo e(Form::text("title")); ?>

  <?php echo e(Form::textarea("body")); ?>

  <?php echo e(Form::ymd('pub_date',$post->pub_date)); ?>

  <?php echo e(Form::submit("Save")); ?>

  <?php echo e(Form::close()); ?>

