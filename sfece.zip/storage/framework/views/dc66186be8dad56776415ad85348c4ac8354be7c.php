<?php
  $class=$attributes["class"];
  unset($attributes["class"]);
?>
<?php echo e(Form::text($name, $value, array_merge(["class"=>$class." date"],(array)$attributes))); ?>

