<h1>Click the Link To Verify Your Email</h1>

Click the following link to verify your email {{route('email.verify',$email_token)}}
