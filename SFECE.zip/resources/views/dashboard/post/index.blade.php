
@extends('layouts.admin')
@section('content')
<section class="post-dashboard">
<div class="panel-group">
    <div class="panel panel-default">
        <div class="panel-body" style="padding: 7px;">
            <a class="btn btn-success btn-sm pull-right" href="{{route('cp.posts.create',['type'=>$post_type_id,'curr_menu'=>$sel_menu])}}">
          Create New</a>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-body">
            <table class="table table-hover table-striped datatable">
                <thead>
                  <tr>
                      <th>Image</th>
                    <th>Title</th>
                    <th>Created Date</th>
                    <th>Publish Date</th>
                    <th>Author</th>
                      <th>File</th>
                    <th></th>
                      <th></th>
                  </tr>
                </thead>
                @foreach($data as $post)
                  <tr>
                      <td><img src="{{$post->mainImage()}}" class="img-responsive" width="100px"/></td>
                      <td>{{$post->title}}</td>
                      <td>{{$post->created_at}}</td>
                      <td>{{$post->pub_date}}</td>
                      <td>{{$post->Creator!=null?$post->Creator->name:null}}</td>
                      <td>
                          <a href="#" title="Publish/UnPublish Post" data-id="{{$post->id}}" class="btn btn-default {{($post->is_published)?"unpublish":"publish"}}"><span class="glyphicon glyphicon-globe {{($post->is_published)?"text-success":"text-danger"}}"></span></a>
                      </td>
                      <td>@if($post->mainFile())<a href="/uploads/files/{{$post->mainFile()}}">Download</a>@endif</td>
                      <td>
                          {!!Func::actionLinks('posts',$post->id,"",["view"=>['class'=>"view1","target"=>"_blank",'href'=>"/".app()->getLocale()."/".$post->slug]])!!}
                      </td>

                  </tr>
                @endforeach
              </table>
        </div>
    </div>
</div>
</section>
@endsection

@section('js')
<script>
$(function(){
  $("body").on("click",".publish",function(e){
      e.preventDefault();
      var $this=$(this);
      $.ajax({
            headers:{'X-CSRF-TOKEN':'{{csrf_token()}}'},
            url:"{{route('cp.post-publish')}}",
            type:"post",
            dataType:"json",
            data:{id:$this.data("id")},
            beforeSubmit:function(){
              return confirm("Are you sure you want to publish this post?");
            },
            success:function(d, statusText, xhr,form){
              if(d.type=="success"){
                  Success(d.message);
                  $this.toggleClass("publish");
                  $this.toggleClass("unpublish");
                  $this.find("span").toggleClass("text-danger");
                  $this.find("span").toggleClass("text-success");
              }else{
                  Error(d.message);
              }
            },
            error: function (data, status, xhr) {
                Error( data.status + " " + xhr);
            }
      });
  });
    $("body").on("click",".unpublish",function(e){
        e.preventDefault();
        var $this=$(this);
        $.ajax({
            headers:{'X-CSRF-TOKEN':'{{csrf_token()}}'},
            url:"{{route('cp.post-unpublish')}}",
            type:"post",
            dataType:"json",
            data:{id:$this.data("id")},
            beforeSubmit:function(){
                return confirm("Are you sure you want to un-publish this post?");
            },
            success:function(d, statusText, xhr,form){
                if(d.type=="success"){
                    Success(d.message);
                    $this.toggleClass("publish");
                    $this.toggleClass("unpublish");
                    $this.find("span").toggleClass("text-danger");
                    $this.find("span").toggleClass("text-success");
                 }else{
                    Error(d.message);
                }
            },
            error: function (data, status, xhr) {
                Error( data.status + " " + xhr);
            }
        });
    });
});
</script>

@endsection
