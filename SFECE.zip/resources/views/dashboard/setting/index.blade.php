@extends('layouts.admin')
@section('content')
<section class="user-dashboard">
<div class="panel-group">

    <div class="panel panel-default">
        <div class="panel-body" style="padding: 7px;min-height: 600px;">

        </div>
    </div>
</div>
</section>
@endsection

@section('js')

@endsection
