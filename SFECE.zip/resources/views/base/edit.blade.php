

@extends('layouts.admin')
@section('content')


<div class="alert alert-danger">Please create view in the first </div>

@stop
