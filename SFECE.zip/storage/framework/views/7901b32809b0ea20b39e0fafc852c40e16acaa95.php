<?php $__env->startSection('content'); ?>
<section class="post-dashboard">
<div class="panel panel-default">
    <div class="panel-body">
        <h2 class="post-heading">Edit <?php echo e(App\Models\PostType::find($data->post_type_id)->name); ?>: <small><?php echo e($data->title); ?></small></h2>
        <?php echo e(Form::model($data, ['route'=>["cp.posts.update",$data->id,'curr_menu'=>$sel_menu],"method"=>"PUT","enctype"=>"multipart/form-data"])); ?>

        <div class="form-horizontal">
            <ul class="nav nav-tabs">
                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="<?php echo e(($key==app()->getLocale())?'active':''); ?>">
                        <a data-toggle="tab" href="#data_<?php echo e($key); ?>"><?php echo e($key); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

            <div class="tab-content">
                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="data_<?php echo e($key); ?>" class="tab-pane fade in <?php echo e(($key==app()->getLocale())?'active':''); ?>">

                <div class="form-group">
                    <label class="control-label col-md-2">Title</label>
                    <div class="col-md-10">
                      <?php echo e(Form::text($key."[title]",($data->translate($key)!=null?$data->translate($key)->title:null),['class'=>'form-control'])); ?>

                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-2">Content</label>
                    <div class="col-md-10">
                      <?php echo e(Form::textarea($key."[body]",($data->translate($key)!=null?$data->translate($key)->body:null),['class'=>'form-control editor','id'=>$key.'_editor'])); ?>

                    </div>
                </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group" style="padding-top:10px;">
                    <label class="control-label col-md-2">Url</label>
                    <div class="col-md-10">
                        <?php echo e(Form::text("slug",$data->slug,['required','class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
            <?php if($data->post_type_id==1): ?>
                <?php echo e(Form::hidden('category_id',0)); ?>

            <?php else: ?>

            <div class="form-group">
                <label class="control-label col-md-2">Category</label>
                <div class="col-md-10">
                    <?php echo e(Form::select("category_id",Func::getCategoriesList(),$data->category_id,['class'=>'form-control'])); ?>

                </div>
            </div>

            <?php endif; ?>
            <?php echo e(Form::hidden('post_type_id',$data->post_type_id)); ?>

            <div class="form-group">
                <label class="control-label col-md-2">Image</label>
                <div class="col-md-10">
                    <?php echo e(Form::file("image",['accept'=>'.jpg,.png,.gif'])); ?>

                </div>
            </div>
            <hr>
            <div class="form-group">
                <div class="col-md-offset-2 col-md-10">
                    <button type="submit" class="btn btn-success save"><i class="fa fa-save"></i> Save</button>
                </div>
            </div>
            </div>
        <?php echo e(Form::close()); ?>

    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>