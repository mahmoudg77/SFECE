<?php $__env->startSection('title',$data->title); ?>
<?php $__env->startSection('content'); ?>

<div class="panel panel-default" style="width:700px;max-width: 100%;">
    <div class="panel-heading main-color-bg">
      <h3 class="panel-title">Edit User :: <?php echo e($data->name); ?></h3>
    </div>

    <div class="modal-body">
      <div class="row">
        <?php echo e(Form::model($data, ['route'=>["cp.user.update",$data->id],"method"=>"PUT"])); ?>


        <div class="form-group col-sm-6">
              <?php echo Form::label('Name'); ?>

              <?php echo Form::text('name', null, ['required', 'class'=>'form-control', 'placeholder'=>'']); ?>

            </div>

            <div class="form-group col-sm-12">
              <?php echo Form::label('Email'); ?>

              <?php echo Form::text('email', null, ['required', 'class'=>'form-control','type'=>'email', 'placeholder'=>'']); ?>

            </div>
            <div class="form-group col-sm-12">
              <?php echo Form::label('Country'); ?>

              <?php echo Form::text('country', null, ['class'=>'form-control', 'placeholder'=>'']); ?>

            </div>
            <div class="form-group col-sm-12">
              <?php echo Form::label('City'); ?>

              <?php echo Form::text('city', null, ['class'=>'form-control', 'placeholder'=>'']); ?>

            </div>
            <div class="form-group col-sm-12">
              <?php echo Form::label('Phone'); ?>

              <?php echo Form::text('phone', null, ['class'=>'form-control', 'placeholder'=>'']); ?>

            </div>

          <div class="form-group col-sm-6">
            <?php echo Form::label('Account Type?'); ?>

            <?php echo Form::select('account_level_id', App\Models\AccountLevel::pluck('name','id'), null, array('class'=>'form-control', 'placeholder'=>'Select parent')); ?>

          </div>


        <hr/>
        <div class="model-footer form-group col-sm-12" style="">
            <?php echo Form::submit('Update', array('class'=>'btn btn-success pull-right')); ?>

        </div>
      <?php echo Form::close(); ?>

      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>