<?php $__env->startSection('content'); ?>
<div class="">
  <a class="btn btn-success pull-right" href="<?php echo e(route('cp.secpermission.create',['curr_menu'=>$sel_menu])); ?>">Create New</a>
  <table class="table datatable">
    <thead>
      <tr>
        <th>Controller</th>
        <th>Action</th>
        <th>Author</th>
        <th></th>
      </tr>
    </thead>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td><?php echo e($itemt->controller); ?></td>
          <td><?php echo e($itemt->action); ?></td>
          <td><?php echo e($itemt->Creator!=null?$itemt->Creator->name:null); ?></td>
          <td>
              <?php echo Func::actionLinks('secpermission',$itemt->id,"",["edit"=>['class'=>"edit"],"view"=>['class'=>"view"]]); ?>

          </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>