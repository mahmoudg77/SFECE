<?php if(Request::ajax()): ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('js'); ?>
<?php else: ?>

<?php
  $mainmenu=$cp_menu;
  $qmenu=app('request')->input('curr_menu');
  //if(!$qmenu)$qmenu="Category";
  ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Admin | <?php echo $__env->yieldContent('title', 'cp'); ?></title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="<?php echo e(asset('cp/css/style.css')); ?>" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="http://cdn.ckeditor.com/4.6.1/standard/ckeditor.js"></script>
    <link href="<?php echo e(asset('cp/css/jquery-ui.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('cp/css/jquery.datetimepicker.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('cp/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('cp/css/buttons.dataTables.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('cp/css/iziToast.min.css')); ?>" rel="stylesheet" />

    <?php echo $__env->yieldContent('css'); ?>
   </head>
  <body>

    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo e(route('cp.dashboard')); ?>">Dashboard</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            
            <?php $__currentLoopData = $mainmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(Auth::user()->hasRoles($menu['roles'])): ?>
                <li class="<?php echo e($qmenu==$key?'active':''); ?>"><a  href="<?php echo e($menu['url']); ?>"><?php echo e($key); ?></a></li>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </ul>
          <ul class="nav navbar-nav navbar-right">

            <?php if(Auth::guest()): ?>
                <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
            <?php else: ?>
                <li><a href="#">Welcome, <?php echo e(Auth::user()->name); ?></a></li>
                <li>
                  <a href="<?php echo e(route('logout')); ?>"
                      onclick="event.preventDefault();
                               document.getElementById('logout-form').submit();">
                      Logout
                  </a>

                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo e(csrf_field()); ?>

                  </form>
                </li>
            <?php endif; ?>
                <li>
                <a href="<?php echo e(route('swichlang')); ?>"><?php echo e((app()->getLocale()=='ar')?'en':'ع'); ?></a>
                </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Cpanel <small>Manage Your Site</small></h1>
          </div>

        </div>
      </div>
    </header>

    

    <section id="main" style="min-height: 600px;">
      <div class="container">
        <div class="row">
          <?php if($qmenu): ?>
          <div class="col-md-3">
            <div class="list-group">
              <!-- <a class="list-group-item active main-color-bg">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Cpanel
              </a>
              <a href="<?php echo e(route('cp.category.index')); ?>" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Categories <span class="badge">12</span></a>
              <a href="/admin/customer" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Customers <span class="badge">12</span></a>

              <?php $__currentLoopData = App\Models\PostType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('cp.posts.index')); ?>?type=<?php echo e($posttype->id); ?>" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> <strong><?php echo e($posttype->name); ?></strong>  <span class="badge"><?php echo e(count($posttype->Posts)); ?></span></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <a class="list-group-item"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> <strong>Users <strong></a>
              <?php $__currentLoopData = App\Models\AccountLevel::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('cp.user.index')); ?>?level=<?php echo e($level->id); ?>" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> <?php echo e($level->name); ?><span class="badge"><?php echo e(count($level->Accounts)); ?></span></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->

              <a class="list-group-item active main-color-bg">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Cpanel
              </a>

              <?php $__currentLoopData = $mainmenu[$qmenu]['submenu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->hasRoles($menu['roles'])): ?>
                  <a href="<?php echo e($menu['url']); ?>" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> <?php echo e($key); ?> </a>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </div>

          </div>

          <div id="page-container" class="col-md-9">
            <?php else: ?>
            <div id="page-container" class="col-md-12">
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>


          </div>
        </div>
      </div>
    </section>
    <div id="myModal" class="modal fade  " role="dialog">
              <div class="modal-dialog modal-md">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h5 class="modal-title">Create new</h5>
                      </div>
                      <div class="modal-body">

                      </div>
                      <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                  </div>

              </div>
          </div>


  <script>
    // CKEDITOR.replace( 'editor1' );
 </script>

    <!-- Bootstrap core JavaScript
    ================================================== -->

    <!-- jQuery library -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <!-- Latest compiled JavaScript -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!--Ajax Form library-->
    <script src="<?php echo e(asset('cp/js/jquery.form.js')); ?>"></script>

    <script src="<?php echo e(asset('cp/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cp/js/jquery.datetimepicker.full.js')); ?>"></script>
    <script src="<?php echo e(asset('cp/js/iziToast.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cp/js/ckfinder/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('cp/js/ckfinder/ckfinder.js')); ?>"></script>
    <script src="<?php echo e(asset('cp/js/script.js')); ?>"></script>
    <?php if(Session::has('response')){
        $response=session()->pull('response');
        //dd($response);
    }?>
    <?php if(isset($response) && $response['type']=='success'): ?>
        <script>$(function(){Success("<?php echo e($response['message']); ?>");});</script>
    <?php endif; ?>
    <?php if(isset($response) && $response['type']=='error'): ?>
        <script>$(function(){Error("<?php echo e($response['message']); ?>");});</script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('js'); ?>


  </body>
</html>
<?php endif; ?>
