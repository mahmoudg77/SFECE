<?php $__env->startSection('content'); ?>
<section class="user-dashboard">
<div class="panel-group">
    <div class="panel panel-default">
        <div class="panel-body" style="padding: 7px;">
            <a class="btn btn-success pull-right" href="<?php echo e(route('cp.user.create',['curr_menu'=>$sel_menu])); ?>">Create New</a>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-body" style="padding: 7px;">
            <table class="table datatable">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Email</th>
                    <th>Register Date</th>
                    <th></th>
                  </tr>
                </thead>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($item->name); ?></td>
                      <td><?php echo e($item->email); ?></td>
                      <td><?php echo e($item->AccountLevel->name); ?></td>
                      <td><?php echo e($item->created_at); ?></td>
                       <td>
                          <?php echo Func::actionLinks('user',$item->id,"",["edit"=>['class'=>"edit"],"view"=>['class'=>"view"]]); ?>

                      </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>