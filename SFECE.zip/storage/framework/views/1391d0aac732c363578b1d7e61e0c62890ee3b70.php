<?php $__env->startSection('content'); ?>
<div class="panel panel-default" style="margin-bottom:10px">
    <div class="panel-body" style="padding:7px">
        <a class="btn btn-success pull-right" href="<?php echo e(route('cp.category.create',['curr_menu'=>$sel_menu])); ?>">Create New</a>
    </div>
</div>

<div class="panel panel-default cat-dashboard">
    <div class="panel-body">
        <div class="list-group" >
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(count($item->Chields)>0): ?>
            <div class="list-group-item">
                <div class="row">
                    <a href="#<?php echo e($item->id); ?>" class="col-sm-8" data-toggle="collapse" style="color: #555;text-decoration: none;">
                        <?php echo e($item->title); ?> <i class="glyphicon glyphicon-chevron-right" style="font-size: 12px;"></i></a>
                    <div class="col-sm-4 pull-right">
                        <?php echo Func::actionLinks('category',$item->id,".list-group-item",['edit'=>['class'=>'edit'],'view'=>['class'=>'view']]); ?>

                    </div>
                </div>
            </div>
          <?php else: ?>
            <div class="list-group-item">
                <div class="row">
                  <div class="col-sm-8"><?php echo e($item->title); ?></div>
                  <div class="col-sm-4 pull-right">
                     <?php echo Func::actionLinks('category',$item->id,".list-group-item",['edit'=>['class'=>''],'view'=>['class'=>'view']]); ?>

                  </div>
                </div>
            </div>
          <?php endif; ?>

          <?php if(count($item->Chields)>0): ?>
            <div class="list-group collapse" id="<?php echo e($item->id); ?>">
              <?php $__currentLoopData = $item->Chields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div  class="list-group-item">
                  <div class="row">
                      <div class="col-sm-8">&nbsp;&nbsp; <?php echo e($subitem->title); ?></div>
                      <div class="col-sm-4 pull-right">
                        <?php echo Func::actionLinks('category',$subitem->id,".list-group-item",['edit'=>['class'=>''],'view'=>['class'=>'view']]); ?>

                      </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>