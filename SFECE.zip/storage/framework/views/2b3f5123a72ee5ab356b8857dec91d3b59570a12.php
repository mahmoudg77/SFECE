<div class="col-xs-hidden col-sm-12">
        <div class="single-sidebar">
            <div class="single-cat">
                <h4><?php echo e(trans('app.categories')); ?></h4>
                <ul class="list-group">
                    <?php $__currentLoopData = $allcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('getPostsByCatID', $cat->id)); ?>"><?php echo e($cat->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="single-cat">
                <h4><?php echo e(trans('app.last articles')); ?></h4>
                <ul class="list-group">
                    <?php $__currentLoopData = $lastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('getPostBySlug', $lastpost->slug)); ?>"><?php echo e($lastpost->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="single-cat">
                <h4><?php echo e(trans('app.follow facebook')); ?></h4>
                <ul class="list-group">
                    <div class="fb-page" data-href="https://www.facebook.com/wwwarabececom/" 
                         data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" 
                         data-hide-cover="false" data-show-facepile="true">
                        <blockquote cite="https://www.facebook.com/elradio1/" class="fb-xfbml-parse-ignore"></blockquote></div>
                </ul>
            </div>
        </div>
</div>