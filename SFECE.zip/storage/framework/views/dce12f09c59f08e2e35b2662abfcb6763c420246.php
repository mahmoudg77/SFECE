<?php $__env->startSection('content'); ?>

<section class="single" style="min-height:500px;">
    <div class="col-xs-12 col-sm-8">
        <div class="single-box">
            <div class="single-img">
                <img src="<?php echo e($singlePost->mainImage()); ?>" class="img-responsive center--block img-thumbanail" >
            </div>

            <div class="single-content">

                <h2><?php echo e($singlePost->title); ?></h2>
                <div class="bar-data">
                    <small>
                        <span><i class="fa fa-user"></i> <?php echo e($singlePost->Creator!=null?$singlePost->Creator->name:null); ?></span>
                        <span><i class="fa fa-folder"></i>
                        <a href="/ar/category/<?php echo e($singlePost->category_id); ?>"><?php echo e($singlePost->Category->title); ?></a></span>
                        <small><span class="glyphicon glyphicon-time"></span>
                        <?php echo e($singlePost->created_at!=null?$singlePost->created_at->toDateString():''); ?></small>
                    </small>
                </div>
                <div class="uderline" style="padding:10px 0.border:1px solid #ddd;"></div>
                <p><?php echo $singlePost->body; ?> </p>

            </div>
            
            <div class="related-post">
            <h4 class="related-post-heading"><?php echo e(trans('app.related posts')); ?></h4>
            <?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('getPostBySlug', $rpost->slug)); ?>">
                    <div class="row">
                        <div class="col-sm-4">
                            <img src="<?php echo e($rpost->mainImage()); ?>" class="media-object">
                            <h4 class="related-post-title"><?php echo e($rpost->title); ?></h4>
                        
                    </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="col-xs-hidden col-sm-4">
        <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>