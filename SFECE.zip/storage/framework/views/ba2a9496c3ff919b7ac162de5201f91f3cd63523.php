<?php $__env->startSection('content'); ?>
<section class="user-dashboard">
<div class="panel-group">

    <div class="panel panel-default">
        <div class="panel-body" style="padding: 7px;min-height: 600px;">

        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>