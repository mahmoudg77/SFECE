<?php $__env->startSection('content'); ?>
<section class="post-dashboard">
<div class="panel-group">
    <div class="panel panel-default">
        <div class="panel-body" style="padding: 7px;">
            <a class="btn btn-success btn-sm pull-right" href="<?php echo e(route('cp.posts.create',['type'=>$post_type_id,'curr_menu'=>$sel_menu])); ?>">
          Create New</a>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-body">
            <table class="table table-hover table-striped datatable">
                <thead>
                  <tr>
                      <th>Image</th>
                    <th>Title</th>
                    <th>Created Date</th>
                    <th>Publish Date</th>
                    <th>Author</th>
                      <th>File</th>
                    <th></th>
                      <th></th>
                  </tr>
                </thead>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><img src="<?php echo e($post->mainImage()); ?>" class="img-responsive" width="100px"/></td>
                      <td><?php echo e($post->title); ?></td>
                      <td><?php echo e($post->created_at); ?></td>
                      <td><?php echo e($post->pub_date); ?></td>
                      <td><?php echo e($post->Creator!=null?$post->Creator->name:null); ?></td>
                      <td>
                          <a href="#" title="Publish/UnPublish Post" data-id="<?php echo e($post->id); ?>" class="btn btn-default <?php echo e(($post->is_published)?"unpublish":"publish"); ?>"><span class="glyphicon glyphicon-globe <?php echo e(($post->is_published)?"text-success":"text-danger"); ?>"></span></a>
                      </td>
                      <td><?php if($post->mainFile()): ?><a href="/uploads/files/<?php echo e($post->mainFile()); ?>">Download</a><?php endif; ?></td>
                      <td>
                          <?php echo Func::actionLinks('posts',$post->id,"",["view"=>['class'=>"view1","target"=>"_blank",'href'=>"/".app()->getLocale()."/".$post->slug]]); ?>

                      </td>

                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(function(){
  $("body").on("click",".publish",function(e){
      e.preventDefault();
      var $this=$(this);
      $.ajax({
            headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'},
            url:"<?php echo e(route('cp.post-publish')); ?>",
            type:"post",
            dataType:"json",
            data:{id:$this.data("id")},
            beforeSubmit:function(){
              return confirm("Are you sure you want to publish this post?");
            },
            success:function(d, statusText, xhr,form){
              if(d.type=="success"){
                  Success(d.message);
                  $this.toggleClass("publish");
                  $this.toggleClass("unpublish");
                  $this.find("span").toggleClass("text-danger");
                  $this.find("span").toggleClass("text-success");
              }else{
                  Error(d.message);
              }
            },
            error: function (data, status, xhr) {
                Error( data.status + " " + xhr);
            }
      });
  });
    $("body").on("click",".unpublish",function(e){
        e.preventDefault();
        var $this=$(this);
        $.ajax({
            headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'},
            url:"<?php echo e(route('cp.post-unpublish')); ?>",
            type:"post",
            dataType:"json",
            data:{id:$this.data("id")},
            beforeSubmit:function(){
                return confirm("Are you sure you want to un-publish this post?");
            },
            success:function(d, statusText, xhr,form){
                if(d.type=="success"){
                    Success(d.message);
                    $this.toggleClass("publish");
                    $this.toggleClass("unpublish");
                    $this.find("span").toggleClass("text-danger");
                    $this.find("span").toggleClass("text-success");
                 }else{
                    Error(d.message);
                }
            },
            error: function (data, status, xhr) {
                Error( data.status + " " + xhr);
            }
        });
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>