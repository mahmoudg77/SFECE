<?php $__env->startSection('content'); ?>
<?php echo e(Form::model(null, ['route'=>["cp.secpermission.store"],"method"=>"POST",'class'=>'ajax-form'])); ?>

<div class="form-horizontal">
            <div class="form-group">
                <label class="control-label col-md-2">Group</label>
                <div class="col-md-10">
                  <?php echo e(Form::select('groupid',App\Models\SecGroup::pluck('name','id'),null,['class'=>'form-control'])); ?>

                </div>
            </div>
              <div class="form-group">
                <label class="control-label col-md-2">Controller</label>
                <div class="col-md-10">
                  <select id="ctrl"  class="form-control" name="ctrl">
                    <?php $__currentLoopData = Func::controllers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
            </div>

        <div class="form-group">
            <label class="control-label col-md-2"></label>
            <div class="col-md-10">
             <table class="table" id="actions">
                 <thead><tr><th>Allow</th><th>Action</th><th>Force Filter</th></tr></thead>
                 <tbody></tbody>
             </table>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-offset-2 col-md-10">
                <button type="submit" class="btn btn-success create"><i class="fa fa-save"></i> Create</button>
            </div>
        </div>
    </div>
<?php echo e(Form::close()); ?>


<script type="text/javascript">
  $(function(){
    $("#ctrl,select[name='groupid']").change(function(){
        $("#actions tbody").html("Loading ...");
      $.ajax({
        type:"post",
        headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'},
        url:"<?php echo e(route('cp.secpermission-getactions')); ?>",
        dataType:'json',
        data:{'ctrl':$("#ctrl").val(),'group':$("select[name='groupid']").val()},
        success:function(d){
          $("#action").html("");
          console.log(d);
          if(d.success){
              $("#actions tbody").html("");
              var n=0;
            d.data.forEach(function(item){
                var tr=$("<tr><input type='hidden' name='"+n+"[controller]' value='" + item.controller + "'/><input type='hidden' name='"+n+"[sec_group_id]' value='" + item.sec_group_id + "'/></tr>");
                tr.append("<td><input type='checkbox' name='"+n+"[action]' value='" + item.action + "' " + (item.id>0?"checked":"") + " /></td>");
                tr.append("<td>"+item.action+"</td>");
                tr.append("<td><input type='text' value='" + item.force_filter + "' class='form-control' placeholder='e.g. [[\"column\",\"=\",\"value\"],...]' name='"+n+"[force_filter]'/></td>");

                $("#actions tbody").append(tr);
                n++;
            });
          }else{
              $("#actions tbody").html("");
            Error(d.message);
          }

        },
        error: function (data, status, xhr) {
            $("#actions tbody").html("");
            Error( data.status + " " + xhr);
        }
      });
    });


      $("#ctrl").change();

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>